package com.example.myapplication;

public class Code {
    public static int requestCode = 200;
    public static int resultCode = 1;
}
