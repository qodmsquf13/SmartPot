package com.example.myapplication;

import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.os.ParcelUuid;

import java.util.UUID;

public class ListViewItem {
    private String address;
    private String name;
    private BluetoothDevice device;

    public void setAddress(String address) {
        this.address = address;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setDevice(BluetoothDevice device) {this.device = device;}
    public String getAddress(){ return this.address; }
    public String getName() { return this.name; }
    public BluetoothDevice getDevice() { return this.device; }
}
