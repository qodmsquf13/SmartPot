package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_ENABLE_BT = 1;
    public Button button1;
    public Switch switch1;
    public BluetoothDevice device;
    public BluetoothAdapter bluetoothAdapter;
    public BluetoothGatt bluetoothGatt;
    public BluetoothGattService bluetoothGattService;
    public BluetoothGattCharacteristic bluetoothGattCharacteristic;
    public UUID serviceUuid = UUID.fromString("0000FFE0-0000-1000-8000-00805F9B34FB");
    public UUID characteristicUuid = UUID.fromString("0000FFE1-0000-1000-8000-00805F9B34FB");
    public boolean mScanning = true;
    public static final long SCAN_PERIOD = 4000;
    private int connectionState = STATE_DISCONNECTED;

    private static final int STATE_DISCONNECTED = 0;
    private static final int STATE_CONNECTING = 1;
    private static final int STATE_CONNECTED = 2;

    public final static String ACTION_GATT_CONNECTED =
            "com.example.bluetooth.le.ACTION_GATT_CONNECTED";
    public final static String ACTION_GATT_DISCONNECTED =
            "com.example.bluetooth.le.ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_SERVICES_DISCOVERED =
            "com.example.bluetooth.le.ACTION_GATT_SERVICES_DISCOVERED";
    public final static String ACTION_DATA_AVAILABLE =
            "com.example.bluetooth.le.ACTION_DATA_AVAILABLE";
    public final static String EXTRA_DATA =
            "com.example.bluetooth.le.EXTRA_DATA";
    public boolean isReadEnabled = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("qodmsquf","MainActivity Log");


        try {
            BroadcastReceiver gattUpdateReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    final String action = intent.getAction();
                    if(action.equals(ACTION_GATT_SERVICES_DISCOVERED)){
                        try {
                            Log.i("qo","서비스 발견 브로드캐스트");
                            bluetoothGattService = bluetoothGatt.getService(serviceUuid);
                            bluetoothGattCharacteristic = bluetoothGattService.getCharacteristic(characteristicUuid);
                            if(bluetoothGattCharacteristic != null) {
                                int properties = bluetoothGattCharacteristic.getProperties();
                                int permission = bluetoothGattCharacteristic.getPermissions();
                                int type = bluetoothGattCharacteristic.getWriteType();
                                Log.i("qo","properties:"+String.valueOf(properties) + "permission:"+String.valueOf(permission)+"type:"+type);
                                switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                    @Override
                                    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                        if (b) {
                                            Log.i("qo", "활성화");
                                            if (bluetoothGattService != null) {
                                                try {
                                                    Toast.makeText(getApplicationContext(), "On", Toast.LENGTH_SHORT).show();
                                                    bluetoothGattCharacteristic.setValue("1");
                                                    bluetoothGatt.writeCharacteristic(bluetoothGattCharacteristic);
                                                    bluetoothGatt.setCharacteristicNotification(bluetoothGattCharacteristic,true); // 알림 설정 결과는 밑에 브로트캐스트 업데이트를 통해 방송됌
                                                    Log.i("qo", "ON");
                                                } catch (Exception e) {
                                                    Log.i("qo", String.valueOf(e));
                                                    throw e;
                                                }
                                            }
                                        } else {
                                            Log.i("qo", "비활성화");
                                            if (bluetoothGattService != null) {
                                                try {
                                                    Toast.makeText(getApplicationContext(), "Off", Toast.LENGTH_SHORT).show();
                                                    bluetoothGattCharacteristic.setValue("2");
                                                    bluetoothGatt.writeCharacteristic(bluetoothGattCharacteristic);
                                                    isReadEnabled = false;
                                                    bluetoothGatt.setCharacteristicNotification(bluetoothGattCharacteristic,false);
                                                    Log.i("qo", "OFF");
                                                } catch (Exception e) {
                                                    Log.i("qo", String.valueOf(e));
                                                }
                                            }
                                        }
                                    }
                                });
                            }
                        }catch (Exception e){
                            throw e;
                        }
                    }
                }
            };
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(ACTION_GATT_CONNECTED);
            intentFilter.addAction(ACTION_GATT_SERVICES_DISCOVERED);
            registerReceiver(gattUpdateReceiver,intentFilter);

            button1 = (Button) findViewById(R.id.Button1);
            switch1 = (Switch) findViewById(R.id.switch1);

            bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            if(!isSupport(bluetoothAdapter)){
                Toast.makeText(getApplicationContext(),"블루투스를 지원하지 않습니다.",Toast.LENGTH_SHORT).show();
            }

            if (!bluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }

            button1.setOnClickListener(new ImageButton.OnClickListener() {
                @Override
                public void onClick(View view){
                    Toast.makeText(getApplicationContext(),"블루투스 버튼 클릭",Toast.LENGTH_SHORT).show();

                    BluetoothLeScanner scanner = bluetoothAdapter.getBluetoothLeScanner();
                    scanLeDevice(mScanning,scanner);

//                    BluetoothGattCallback gattCallback = new BluetoothGattCallback() {};
//                    bluetoothGatt = device.connectGatt(getApplicationContext(),true,gattCallback);
                }
            });



        }catch (Exception e){
            Log.e("qo",String.valueOf(e));
        }
    }

    protected boolean isSupport(BluetoothAdapter object){
        try{
            if(object == null){
                return false;
            }else{
                return true;
            }
        }catch (Exception e){
            throw e;
        }
    }

    private void scanLeDevice(final boolean enable, BluetoothLeScanner bluetoothLeScanner) {
        try {
            ScanCallback leScanCallback = new ScanCallback() {
                @Override
                public void onScanResult(int callbackType, ScanResult result) {
                    BluetoothDevice device2 = result.getDevice();
                    String device2Name = device2.getName();
                    if(device2Name != null){
                        Log.i("qo",device2Name);
                        if(device2Name.equals("HMSoft")){
                            device = device2;
                        }
                    }
                }
            };

            if (enable) {
                Handler handler = new Handler();
                // Stops scanning after a pre-defined scan period.
                handler.postDelayed(new Runnable(){
                    @Override
                    public void run() {
                        mScanning = false;
                        bluetoothLeScanner.stopScan(leScanCallback);
//                        Toast.makeText(getApplicationContext(),"스캔을 완료합니다",Toast.LENGTH_SHORT).show();
                        Log.i("qo","스캔완료");
                        //연결을 시작하는 사용자 함수
                        connectBlue();
                    }
                }, SCAN_PERIOD);
                mScanning = false;
//                Toast.makeText(getApplicationContext(),"스캔을 시작합니다.",Toast.LENGTH_SHORT).show();
                bluetoothLeScanner.startScan(leScanCallback);
                Log.i("qo","스캔시작");
            } else {
//                Toast.makeText(getApplicationContext(), "스캔을 중지합니다", Toast.LENGTH_SHORT).show();
                bluetoothLeScanner.stopScan(leScanCallback);
                Log.i("qo","스캔중지");
                mScanning = false;
            }
        }catch (Exception e){
            Log.e("qo",String.valueOf(e));
        }
    }
    public void connectBlue(){
        Log.i("qo","연결시작하기");
        try{
            if(device != null){
                BluetoothGattCallback gattCallback =
                        new BluetoothGattCallback() {
                            @Override
                            public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
                                //GATT 클라이언트가 원격 GATT서버에 연결/해제를 되었을때를 나타내는 콜백.
                                //status 연결안됌0,연결중1,연결완료2
                                if (newState == 2) {
                                    connectionState = STATE_CONNECTED;
                                    //원격 장치에서 제공하는 서비스와 해당 특성 및 설명자를 검색합니다 검색이 실행되면 true를 반환 콜백함수. bluetoothGatt.discoverServices();
                                    Log.i("qo","GATT클라이언트가 원격 GATT서버에 연결됨" + bluetoothGatt.discoverServices());
                                  broadcastUpdate(ACTION_GATT_CONNECTED);
                                } else if (newState == 0) {

                                }
                            }

                            @Override
                            public void onServicesDiscovered(BluetoothGatt gatt, int status) {
                                //원격 장치에 대한 원격 서비스, 특성 및 설명자의 목록이 업데이트되었을 때, 즉 새로운 서비스가 발견되었을 때 호출되는 콜백입니다.
                                //status 성공0
                                if (status == BluetoothGatt.GATT_SUCCESS) {
                                    Log.i("qo","새로운 서비스가 발견되었을 때 호출되는 콜백" + status);
                                    broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED);
                                } else {
                                    Log.w("qo", "onServicesDiscovered received: " + status);
                                }
                            }

                            @Override
                            // 원격 특성 알림의 결과로 트리거된 콜백입니다.
                            public void  onCharacteristicChanged(BluetoothGatt gatt,
                                                             BluetoothGattCharacteristic characteristic
                                                             ) {
                                broadcastUpdate(ACTION_DATA_AVAILABLE,characteristic);
                            }
                        };

                bluetoothGatt = device.connectGatt(getApplicationContext(),true,gattCallback);
                Toast.makeText(getApplicationContext(),"연결 되었습니다.",Toast.LENGTH_SHORT).show();
            }else {
                Log.i("qo","디바이스 없음");
            }
        }catch (Exception e){
            Log.e("qo",String.valueOf(e));
        }
    }


    //연결,해제 또는 새로운서비스를 발견했을때 트리거 되는 콜백
    public void broadcastUpdate(final String action){
        try {
            Log.i("qo",action);
            final Intent intent = new Intent(action);
            sendBroadcast(intent);
        }catch (Exception e){

        }
    }



    //알림의 결과로 트리거 되는 콜백
    public void broadcastUpdate(final String action, BluetoothGattCharacteristic characteristic){
        try {
            Log.i("qo","읽기 쓰기 후 알림을 보고함");
            if(action.equals(ACTION_DATA_AVAILABLE)){
                Log.i("qo","속성을 read합니다");
                while (isReadEnabled){
                    Thread.sleep(1000);
                    String value = bluetoothGattCharacteristic.getStringValue(18);
                    if(value != null){
                        Toast.makeText(getApplicationContext(),"속성을 읽습니다.",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }catch (Exception e){
            Log.i("qo",String.valueOf(e));
        }
    }

}