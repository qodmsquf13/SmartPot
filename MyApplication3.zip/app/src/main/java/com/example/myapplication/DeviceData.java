package com.example.myapplication;

import android.bluetooth.BluetoothDevice;

import java.io.Serializable;

public class DeviceData implements Serializable
{
    public BluetoothDevice device;
    public void DeviceData(BluetoothDevice device){
        this.device = device;
    }
}
