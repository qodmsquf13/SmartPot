package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.BluetoothGattCallback;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.ParcelUuid;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;

public class Bluetooth extends AppCompatActivity {
    public int REQUEST_ENABLE_BT = 1;
    public boolean mScanning = true;
    public static final long SCAN_PERIOD = 4000;
    static public ListView listview;
    public BluetoothGatt bluetoothGatt;
    public BluetoothGattService service;
    public int connectionState = STATE_DISCONNECTED;

    public static final int STATE_DISCONNECTED = 0;
    public static final int STATE_CONNECTING = 1;
    public static final int STATE_CONNECTED = 2;

    public final static String ACTION_GATT_CONNECTED =
            "com.example.bluetooth.le.ACTION_GATT_CONNECTED";
    public final static String ACTION_GATT_DISCONNECTED =
            "com.example.bluetooth.le.ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_SERVICES_DISCOVERED =
            "com.example.bluetooth.le.ACTION_GATT_SERVICES_DISCOVERED";
    public final static String ACTION_DATA_AVAILABLE =
            "com.example.bluetooth.le.ACTION_DATA_AVAILABLE";
    public final static String EXTRA_DATA =
            "com.example.bluetooth.le.EXTRA_DATA";
//    static private final ListViewAdapter adapter = new ListViewAdapter();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);

        listview = findViewById(R.id.listview1);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {

                ListViewItem item = (ListViewItem) parent.getItemAtPosition(position) ;
                Log.i("qo","아이템클릭");
                BluetoothDevice device = item.getDevice();
                BluetoothGattCallback gattCallback =
                        new BluetoothGattCallback() {

                        };
                bluetoothGatt = device.connectGatt(getApplicationContext(),true,gattCallback);
                Toast.makeText(getApplicationContext(),"연결 되었습니다.",Toast.LENGTH_SHORT).show();
                Intent controlInttent = new Intent(Bluetooth.this,controlActivity.class);
                startActivity(controlInttent);
//
//                Intent resultIntent = new Intent();
//                setResult(Code.resultCode, resultIntent);
//                finish();
            }
        }) ;

        try {
            BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            if(!isSupport(bluetoothAdapter)){
                Toast.makeText(getApplicationContext(),"블루투스를 지원하지 않습니다.",Toast.LENGTH_SHORT).show();
            }else{
            }
            if (!bluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }else{
                BluetoothLeScanner scanner = bluetoothAdapter.getBluetoothLeScanner();
                scanLeDevice(true,scanner);
            }

        }catch (Exception e){
            throw e;
        }
    }

    protected boolean isSupport(BluetoothAdapter object){
        try{
            if(object == null){
                return false;
            }else{
                return true;
            }
        }catch (Exception e){
            System.out.println("exception");
            throw e;
        }
    }

    private void scanLeDevice(final boolean enable, BluetoothLeScanner bluetoothLeScanner) {
        try {
            ScanCallback leScanCallback = new ScanCallback() {
                @Override
                public void onScanResult(int callbackType, ScanResult result) {
                    BluetoothDevice device = result.getDevice();
                    ListViewAdapter adapter = new ListViewAdapter();
                    listview.setAdapter(adapter);
                    ParcelUuid[] uuid = device.getUuids();
                    String name = device.getName();
                    adapter.addItem(device.getAddress(),name,device);
                    Log.i("qo","callback");
                }
            };

            if (enable) {
                Handler handler = new Handler();
                // Stops scanning after a pre-defined scan period.
                handler.postDelayed(new Runnable(){
                    @Override
                    public void run() {
                        mScanning = false;
//                        Toast.makeText(getApplicationContext(),"스캔을 완료합니다",Toast.LENGTH_SHORT).show();
                        Log.i("qo","stopScan Log");
                        bluetoothLeScanner.stopScan(leScanCallback);

                    }
                }, SCAN_PERIOD);
                mScanning = true;
//                Toast.makeText(getApplicationContext(),"스캔을 시작합니다.",Toast.LENGTH_SHORT).show();
                bluetoothLeScanner.startScan(leScanCallback);
                Log.i("qo","startScan Log");
            } else {
//                Toast.makeText(getApplicationContext(), "스캔을 중지합니다", Toast.LENGTH_SHORT).show();
                bluetoothLeScanner.stopScan(leScanCallback);
                Log.i("qo","stopScan Log");
                mScanning = false;
            }
        }catch (Exception e){
            Log.e("qo",String.valueOf(e));
            throw e;
        }
    }
}